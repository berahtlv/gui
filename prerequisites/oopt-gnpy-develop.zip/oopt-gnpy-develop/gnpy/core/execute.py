#!/usr/bin/env python3

'''
gnpy.core.execute
=================

This module contains functions for executing the propogation of
spectral information on a `gnpy` network.
'''
