UNITS = {'m': 1,
         'km': 1E3}
